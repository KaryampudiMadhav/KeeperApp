export default function Footer(shiva){
    return(
    <footer className="footer">
        Copyright @ {shiva.date}
    </footer>
    )
}