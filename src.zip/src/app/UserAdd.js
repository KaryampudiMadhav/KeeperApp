import { useEffect, useState } from "react"
import notes from "./notes";
export default function UserAdd(props){
    // useEffect(()=>{
    //     console.log(toDoData);
    // },[toDoData])
    return <>
    <div className="totalContent">
    <div className="userInput">
        <div>
        <input type="text" placeholder="Title"  className="title" onChange={props.changeTitle} value={props.title} />
        </div>
        <div>
        <textarea rows={7} cols={50} placeholder="Enter the Content.........." onChange={props.changeData} value={props.data} >
        </textarea>
        <button className="addItem" onClick={props.addTodo} >Add</button>
        </div>
    </div>
    </div>
    </>
}