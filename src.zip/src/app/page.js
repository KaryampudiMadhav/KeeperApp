'use client'
import { useEffect, useState,useRef } from "react";
import './keeper.css';
import Header from "./header";
import Footer from "./footer";
import notes from "./notes";
import  Content from "./content";
import UserAdd from "./UserAdd";
export default function Home() {
  const [date,setDate] = useState(2025);
  const [title,setTitle] = useState('')
  const [data,setData] = useState('')
  const [toDoData,setToDoData] = useState(notes)
  const [count,setCount] = useState(6)
  const refs = useRef({})
  function changeTitle(e){
      setTitle(e.target.value);
  }  
  function handleRtitle(e,id){
     if(e.type === 'blur' || e.key === "Enter"){
       e.preventDefault();
      setToDoData(prevItems => prevItems.map(items =>{
       return  items.key === id ? {...items , title:e.target.innerText,isEdit:false} : items 
      }))
     }
  }
  function handleContent(e,id){
    if(e.type === 'blur' || e.key === "Enter"){
      e.preventDefault(); 
      setToDoData(prevItems => prevItems.map(items =>{
        return  items.key === id ? {...items , content:e.target.innerText,isEdit:false} : items 
      }))
    }
 }
  function changeData(e) {
      setData(e.target.value);
  }
  function RenderDate() {
    let currentdate = new Date;
    setDate(currentdate.getFullYear());
  }
  useEffect(()=>{
    RenderDate();
  },[])
  function addTodo(){
    setToDoData(prevValue => [...prevValue,{
        key : count,
        title : title || "Untitled",
        content : data || "No Content",
        isEdit : false
    }]);
    console.log(toDoData)
    setCount(count+1);
    setData('')
    setTitle('')
}
function removeItem(id){
  setToDoData(prevData => prevData.filter((d)=>{
    return d.key!= id;
  }))
}
function Editable(id){
  setToDoData(prevItems => 
    prevItems.map((items)=>{
     return  items.key === id ? {...items , isEdit : true} : items
     })
  )

  setTimeout(() => {
    if (refs.current[id]) {
      refs.current[id].focus(); 
    }
  }, 0);
}
  return (
    <>
    <Header />
     <UserAdd addTodo = {addTodo} 
     data ={data} title = {title} 
     changeData ={changeData} changeTitle = {changeTitle} />
     <div className="total">
       {toDoData.map((item) => (
        item && 
         ( <Content 
            key={item.key}
            id={item.key}
            name={item.title}
            content={item.content}
            isEdit={item.isEdit}
            handleContent={(e) => handleContent(e, item.key)}
            handleRtitle={(e) => handleRtitle(e, item.key)}
            removeItem={removeItem}
            Editable={Editable}
            setRef={(el) => (refs.current[item.key] = el)}
          />)
        ))} 
    </div> 
    <Footer date={date} />
    </>
  );
}
