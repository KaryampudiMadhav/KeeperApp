export default function Content(shiva){
  return (
   <div className="keeper">
    {shiva.isEdit ? ( <div className="rtitle"  
    contentEditable = {true}
    suppressContentEditableWarning = {true}
    onKeyDown = {shiva.handleRtitle}
    onBlur = {shiva.handleRtitle}
    >
   {shiva.name}
    </div>) :  (<div className="rtitle" >
   {shiva.name}
    </div> )}
    {shiva.isEdit ? (
    <div className="data"
      contentEditable = {true}
      suppressContentEditableWarning = {true}
      onKeyDown = {shiva.handleContent}
      onBlur = {shiva.handleContent}
      ref={shiva.setRef}
     >
    {shiva.content}
    </div> ) : (
    <div className="data">
    {shiva.content}
    </div>
  )}
    <div className="edit">
      <img src="/edit.png" className="editImg" onClick={()=>{shiva.Editable(shiva.id)}} />
    </div>
    <div className="delete">
      <img src="/delete.png" className="deleteImg"  onClick={()=>shiva.removeItem(shiva.id)} />
    </div>
    </div>
  )
}